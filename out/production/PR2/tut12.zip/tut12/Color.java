package tut12;

public enum Color {
    Blue, Red, Orange, Yellow, Purple
}
