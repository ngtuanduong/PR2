package tut12;

public class NotPossibleException extends RuntimeException {
    public NotPossibleException(String message) {
        super(message);
    }
}
